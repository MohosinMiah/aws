#!/bin/bash

docker build -t php-apache2-laravel-image -f Dockerfile .
docker-compose up -d


# Wait for Elasticsearch to be ready
until $(curl --output /dev/null --silent --head --fail http://localhost:9200); do
    echo "Waiting for Elasticsearch to start..."
    sleep 5
done

# Create indices using curl commands
curl -X PUT "http://localhost:9200/gateway_logs?pretty"
curl -X PUT "http://localhost:9200/report_logs?pretty"
curl -X PUT "http://localhost:9200/apartment_logs?pretty"
curl -X PUT "http://localhost:9200/administrator_logs?pretty"

# Add more index creation commands as needed
