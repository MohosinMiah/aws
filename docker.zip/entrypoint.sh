#!/bin/bash

# Set permissions
chown -R www-data:www-data /var/www/html

# Start Apache
exec apachectl -D FOREGROUND
